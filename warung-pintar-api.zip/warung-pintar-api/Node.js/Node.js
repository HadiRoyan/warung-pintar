mkdir warung-pintar-api
cd warung-pintar-api
npm init -y
npm install express body-parser multer --save

//cek di prompt terminal